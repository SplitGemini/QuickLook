                             Nconvert v7.20
                              XnView v2.46

                   Copyright (c) 1991-2018 Pierre-E Gougelet
                           All Rights Reserved.



Disclaimer
==========

  Installing and using these software (Nview, Nconvert, View2, XnView) signifies acceptance of these terms and conditions of the license.


  XnView/NConvert are provided as Freeware for private non-commercial or educational use, including non-profit organization (i.e. schools, universities, public authorities, police, fire brigade, and hospitals). 
 
  For commercial use and distribution, it is necessary to register. It is a help for the development of future versions. 

  You are granted the right to use and to make an unlimited number of copies of this software.


  These software are provided "as-is". 
  No warranty of any kind is expressed or implied. 
  The author will not be liable for data loss, damages, loss of profits or any other kind of loss while using or misusing this software.
  
  Any suggestions, feedback and comments are welcome. 



Homepage
========

E-Mail:         webmaster@xnview.com
                contact@xnview.com

Web site :      http://www.xnview.com
                http://www.xnview.net
                http://www.xnview.org

NewsGroup :     http://newsgroup.xnview.com


Platforms
=========

  ATARI ST, STe, Falcon, TT and compatible
  PC x86 DOS
  PC x86 Windows 3.1x, 95, 98, NT, Me, 2000, Xp, Vista, 7, 8.1, 10
  PC x86 Linux v2.x (X Window & Lesstif/openMotif)
  PC x86 FreeBSD v3.x (X Window & Lesstif/openMotif)
  Silicon Graphics IRIX v5.2 and above
  Sun Solaris v2.5.1 and above
  Solaris x86 v8.0
  HP-UX v11.0 and above
  AIX v4.2 and above
  BeOS v5.0 and above
  MacOS X


GIF/TIFF LZW reading/writing:
-------------------
  You need to purchase a license because LZW is a patented algorithm. 
  More information is available on http://www.unisys.com

JBIG reading/writing:
-------------------
  You need to purchase a license because JBIG is a patented format. 
  More information is available on http://www.ibm.com and http://www.jpeg.org/

Copyright:
---------

  Default toolbar mezich - http://mezich.livejournal.com
    Icons are only for xnview

  LibJPEG 6b - http://www.ijg.org
    This software is copyright (C) 1991-1998, Thomas G. Lane. All Rights Reserved 

  PNGLib 1.2.5 - http://www.libpng.org/pub/png/
    Copyright (c) 1995, 1996 Guy Eric Schalnat, Group 42, Inc. (libpng versions 0.5, May 1995, through 0.89c, May 1996)
    Copyright (c) 1996, 1997 Andreas Dilger (libpng versions 0.90, December 1996, through 0.96, May 1997)
    Copyright (c) 1998, 1999 Glenn Randers-Pehrson (libpng versions 0.97,January 1998, through 1.0.5, October 15, 1999)

  Zlib 1.2.1 - http://www.gzip.org/zlib/
    Copyright (C) 1995-1998 Jean-loup Gailly and Mark Adler 

  JIF - http://jeff.cafe.net/jif/
    (c) Jeff Tupper

  RAW - http://www.cybercom.net/~dcoffin/dcraw/
    (c) Dave Coffin

Credits:
--------

  Solaris version : Tobias Oetiker
  HP-UX version   : Philippe Choquert
  AIX version     : Philippe Choquert

  Translation:
  ------------
    Afrikaans     : Samuel Murray
    Arabic        : Mohammad Deeb
    Basque        : Axier Lopez
    Bulgarian     : Denis Ivajlov
    Byelorussian  : Alexander Gorbylev
    Catalan       : Jes�s Corrius
    Chinese simplified  : Alexander Yang, Roy Yao
    Chinese traditional : Frank Liu, Alexander Yang
    Croatian      : Josip Sinkovic
    Czech         : Petr Bohdan
    Danish        : Allan Bergmann Jensen
    Dutch         : Michiel Oosterhagen, Theo Eering
    Estonian      : Ahti Kaskpeit
    Finish        : Haukur Krist�fer Bragason, Jouni Paulus
    Galician      : Fernando Coello
    German        : Axel C. Burgbacher, Helmut Mueller
    Greek         : Symeon Charalabides
    Hebrew        : Eitan Gilboa
    Hungarian     : Jozsef Herczeg
    Icelandic     : Svanur P�lsson
    Italian       : Armando R. La Mura, Alexandro F.Proietti
    Japanese      : Sato Kazuyuki, Adrian Ivana, Yong Wei, Motomatsu Nobuhiro
    Korean        : Kim Wooyoung
    Latvian       : Aldis Putelis, Aldis Priednieks
    Lithuanian    : Linas Grinius
    Malaysian     : Ooi Ghee Tiong
    Norwegian     : Lasse Drageset, Lillian Solum
    Polish        : Skiff, Lukasz Jakubowski, Sergiusz Klimkiewicz, Tomasz Fiszer
    Portuguese    : Ant�nio Eduardo Marques
    Portuguese (Brazilian) : Paulo Neto
    Romanian      : Ioan Russu
    Russian       : Alexander Gorbylev, Igor Alikin
    Serbian       : Nik Vukovljak
    Slovak        : Peter Cipov, Lucas Sivak
    Slovene       : Filip Komar, Grega Fajdiga
    Spanish       : Jorge A. Montes P�rez
    Swedish       : Olof T�rnqvist, M�rten Mellberg
    Tha�          : Thanachai Wachiraworakam
    Turkish       : Ibrahim Kutluay
    Ukrainian     : Taras Domansky
    Uzbek         : Sherzod Mamatkulov
    Vietnamese    : Ton, Quang Toai & Vo, Khanh Kim Van
    Welsh         : Geraint Jones

